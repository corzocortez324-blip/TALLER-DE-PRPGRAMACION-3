﻿using ENTIDADES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class ServicioEstudiante : InterfaceEstudiante
    {
        List<Estudiante> estudiantes;

        public ServicioEstudiante()
        {
            estudiantes = new List<Estudiante>();
        }
        public Estudiante ObtenerPorId(int id)
        {
            foreach (var est in estudiantes)
            {
                if ( est.id == id)
                {
                    return est;
                }
            }
            return null;
        }
    }
}
