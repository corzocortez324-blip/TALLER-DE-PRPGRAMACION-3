﻿using ENTIDADES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public class ServicioPedido : InterfacePedido
    {
        public List<Pedido> ObtenerTodos()
        {
            throw new NotImplementedException();
        }

        public string RegistrarPedido(Pedido pedido)
        {
            throw new NotImplementedException();
        }
    }
}
