﻿using ENTIDADES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public interface InterfaceLibro
    {
        Libro ObtenerPorId(int id);
        List<Libro> ObtenerTodos();
    }
}
