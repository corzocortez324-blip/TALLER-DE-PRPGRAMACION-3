﻿using ENTIDADES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
    public interface InterfacePedido
    {
        // Crear
        string RegistrarPedido(Pedido pedido);

        // Leer (todos)
        List<Pedido> ObtenerTodos();

        
        

       
    }
}
