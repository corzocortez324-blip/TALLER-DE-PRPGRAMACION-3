﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTIDADES
{
    public class Pedido
    {
        public int idPedido {  get; set; }
        public Estudiante Estudiante ;
        public Libro libro { get; set; }
        public Pedido()
        {
            
        }

        public void AsignarEstudiante(Estudiante estudiante)
        {
            this.Estudiante = estudiante;
        }

        public void AsignarLibro(Libro libro)
        {
            this.libro = libro;
        }


    }
}
