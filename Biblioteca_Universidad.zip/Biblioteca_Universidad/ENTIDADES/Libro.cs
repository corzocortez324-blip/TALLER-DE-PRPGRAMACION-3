﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTIDADES
{
    public class Libro
    {   
        public int ID;
        public string nombreLibro { get; set; }

        public Libro() { }

        public Libro(string nombreLibro)
        {
            this.nombreLibro = nombreLibro;
        }
    }
}
