﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENTIDADES
{
    public class Estudiante
    {
        public int id { get; set; }
        public string nombre { get; set; }
        
        List<Libro> libros { get; set; }

        public Estudiante()
        {
            libros = new List<Libro>();
        }

        public Estudiante(int id, string nombre)
        {
            this.id = id;
            this.nombre = nombre;
            
        }

      


    }
}
