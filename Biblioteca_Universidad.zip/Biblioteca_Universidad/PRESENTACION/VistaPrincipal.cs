﻿using BLL;
using ENTIDADES;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRESENTACION
{
    public class VistaPrincipal
    {
        ServicioEstudiante servicioEstudiante;
        public VistaPrincipal()
        {
            servicioEstudiante = new ServicioEstudiante();
        }

        public void MenuPricipal()
        {
            int opcion;

            do
            {
                Console.Clear();
                Console.SetCursorPosition(20, 6); Console.Write("1. Registrar Nuevo Pedido ...");
                Console.SetCursorPosition(20, 8); Console.Write("2. Consultar Pedidos ...");
                Console.SetCursorPosition(20, 14); Console.Write("0. Salir");
                Console.SetCursorPosition(17, 4); Console.Write("M E N U   P R I N C I P A L");

                Console.SetCursorPosition(20, 20); Console.Write("Seleccione una opción: ");

                Console.SetCursorPosition(44, 20); opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        RegistrarPedido();
                        break;
                    case 2:

                        break;
                    default:
                        Console.SetCursorPosition(20, 24); Console.WriteLine("Ingrese una opcion valida!");
                        Console.SetCursorPosition(20, 26); Console.WriteLine("PRESIONE ENTER PARA CONTINUAR");
                        Console.SetCursorPosition(49, 26); Console.ReadKey();
                        break;
                }

            } while (opcion != 0);
        }


        public void RegistrarPedido()
        {
            Pedido pedido = new Pedido();

            Console.WriteLine("Ingrese el id del estudiante que realizara el pedido: ");
            int idEstudiante = int.Parse(Console.ReadLine());

            Estudiante estudiante = servicioEstudiante.ObtenerPorId(idEstudiante);

            Console.WriteLine("Ingrese el id del libro: ");
            int idLibro = int.Parse(Console.ReadLine());



            Console.WriteLine("Ingrese el nombre del libro: ");
            string nombreLibro = Console.ReadLine();



            Console.WriteLine();
        }

    }