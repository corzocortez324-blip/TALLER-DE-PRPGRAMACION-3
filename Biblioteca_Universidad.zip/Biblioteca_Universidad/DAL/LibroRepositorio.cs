﻿using ENTIDADES;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class LibroRepositorio
    {
        string ruta = "Libros.txt";
        public Libro ObtenerPorId(int id)
        {
            List<Libro> listaLibros = new List<Libro>();

            listaLibros = ObtenerTodos();
            foreach (Libro libro in listaLibros)
            {
                if (libro.ID == id)
                {
                    return libro;
                }

            }
            return null;
        }

        public List<Libro> ObtenerTodos()
        {
            List<Libro> listaStudents = new List<Libro>();
            try
            {
                StreamReader lector = new StreamReader(ruta);
                while (!lector.EndOfStream)
                {
                    var linea = lector.ReadLine();
                    listaStudents.Add(MapearRaza(linea));
                }
                lector.Close();
                return listaStudents;
            }
            catch (Exception)
            {
                return null;
            }
        }


    }
}
