﻿using BLL;
using ENTIDADES;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class EstudianteRepositorio : InterfaceEstudiante
    {
        string ruta = "Estudiante.txt";
        public Estudiante ObtenerPorId(int id)
        {
            List<Estudiante> listaEstudiantes = new List<Estudiante>();

            listaEstudiantes = ObtenerTodas();
            foreach (Estudiante student in listaEstudiantes)
            {
                if (student.id == id)
                {
                    return student;
                }

            }
            return null;
        }

        public List<Estudiante> ObtenerTodas()
        {
            List<Estudiante> listaStudents = new List<Estudiante>();
            try
            {
                StreamReader lector = new StreamReader(ruta);
                while (!lector.EndOfStream)
                {
                    var linea = lector.ReadLine();
                    listaStudents.Add(MapearRaza(linea));
                }
                lector.Close();
                return listaStudents;
            }
            catch (Exception)
            {
                return null;
            }
        }

        private Estudiante MapearRaza(string linea)
        {
            //   1;unica

            Estudiante est = new Estudiante();

            var aux = linea.Split(';');

            est.id = int.Parse(aux[0]);

            est.nombre = aux[1];

            return est;
            //raza.Id = int.Parse(linea.Split(';')[0]);
        }
    }
}
