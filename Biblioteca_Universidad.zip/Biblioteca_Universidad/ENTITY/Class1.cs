﻿namespace ENTITY;

public class Class1
{

}
